(function() {
  'use strict';

  /* ==========================
     ADVANCED DEBUG LOGGER
  ========================== */

  const DEBUG = true;
  let rollCount = 0;

  const DiceRLogger = {
    styles: {
      base: "font-weight:600;padding:2px 6px;border-radius:4px;",
      info: "background:#1e90ff;color:white;",
      success: "background:#28a745;color:white;",
      warn: "background:#ff9800;color:black;",
      error: "background:#e53935;color:white;",
      event: "background:#6f42c1;color:white;"
    },

    log(type, label, data = null) {
      if (!DEBUG) return;

      const time = new Date().toISOString().split("T")[1].replace("Z", "");
      const style = this.styles[type] || this.styles.info;

      console.groupCollapsed(
        `%c DiceR %c ${type.toUpperCase()} %c ${label} %c ${time}`,
        this.styles.base + "background:#222;color:#fff;",
        this.styles.base + style,
        "font-weight:600;",
        "color:#999;font-size:11px;"
      );

      if (data !== null) console.log(data);

      console.groupEnd();
    },

    time(label) {
      if (!DEBUG) return;
      console.time(`⏱ DiceR ${label}`);
    },

    timeEnd(label) {
      if (!DEBUG) return;
      console.timeEnd(`⏱ DiceR ${label}`);
    }
  };

  DiceRLogger.log("success", "Plugin initialized");

  /* ==========================
     HELPERS
  ========================== */

  function getIdFromPath(regex) {
    const m = window.location.pathname.match(regex);
    DiceRLogger.log("info", "getIdFromPath", { regex: regex.toString(), result: m ? m[1] : null });
    return m ? m[1] : null;
  }

  function getPlural(entity) {
    const plural =
      (entity === "Gallery") ? "Galleries" :
      (entity === "Tag") ? "Tags" :
      (entity === "Image") ? "Images" :
      (entity === "Scene") ? "Scenes" :
      (entity === "Performer") ? "Performers" :
      (entity === "Studio") ? "Studios" :
      (entity === "Group") ? "Groups" :
      entity + "s";

    return plural;
  }

  function getCacheKey(entity, internalFilter) {
    return internalFilter
      ? `randomData_${entity}_${JSON.stringify(internalFilter)}`
      : `randomData_${entity}_global`;
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
  }

  function arraysEqual(a, b) {
    if (!a || !b) return false;
    if (a.length !== b.length) return false;
    const setA = new Set(a);
    for (let id of b) {
      if (!setA.has(id)) return false;
    }
    return true;
  }

  /* ==========================
     RANDOM CORE
  ========================== */

  async function randomGlobal(entity, idField, redirectPrefix, internalFilter) {

    rollCount++;
    DiceRLogger.log("event", `🎲 Roll #${rollCount}`, { entity, internalFilter });

    const realEntityPlural = getPlural(entity);
    const cacheKey = getCacheKey(entity, internalFilter);

    let filterArg = "";
    let filterVar = "";
    let variables = {
      filter: { per_page: -1 }
    };

    if (internalFilter) {
      filterArg = `, $internal_filter: ${entity}FilterType`;
      filterVar = `, ${entity.toLowerCase()}_filter: $internal_filter`;
      variables.internal_filter = internalFilter;
    }

    const query = `
      query Find${realEntityPlural}($filter: FindFilterType${filterArg}) {
        find${realEntityPlural}(filter: $filter${filterVar}) {
          ${idField} { id }
        }
      }
    `;

    DiceRLogger.log("info", "Running GraphQL query", { entity });

    DiceRLogger.time("GraphQL Request");

    let resp = await fetch('/graphql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, variables })
    });

    let data = await resp.json();

    DiceRLogger.timeEnd("GraphQL Request");

    if (data.errors) {
      DiceRLogger.log("error", "GraphQL errors", data.errors);
      alert("Error: " + JSON.stringify(data.errors));
      return;
    }

    let items = data.data[`find${realEntityPlural}`][idField];

    if (!items || items.length === 0) {
      DiceRLogger.log("warn", "No results found");
      alert("No results found.");
      return;
    }

    const currentIds = items.map(i => i.id);

    DiceRLogger.log("success", "Fetched IDs", { count: currentIds.length });

    let stored = JSON.parse(localStorage.getItem(cacheKey) || "null");

    if (!stored || !arraysEqual(stored.allIds, currentIds)) {
      DiceRLogger.log("warn", "Cache rebuilt");
      stored = {
        allIds: currentIds,
        remaining: shuffleArray([...currentIds])
      };
    }

    if (stored.remaining.length === 0) {
      DiceRLogger.log("warn", "Cache exhausted — reshuffling");
      stored.remaining = shuffleArray([...stored.allIds]);
    }

    const nextId = stored.remaining.pop();

    localStorage.setItem(cacheKey, JSON.stringify(stored));

    DiceRLogger.log("success", "Redirecting", {
      nextId,
      remaining: stored.remaining.length
    });

    window.location.href = `${redirectPrefix}${nextId}`;
  }

  /* ==========================
     BUTTON HANDLER
  ========================== */

  async function randomButtonHandler() {
    const pathname = window.location.pathname.replace(/\/$/, '');
    DiceRLogger.log("event", "Button clicked", { pathname });

    if (pathname === '/scenes' || pathname === '/' || pathname === '' ||
        pathname === '/stats' || pathname === '/settings' ||
        pathname === '/scenes/markers' || /^\/scenes\/\d+$/.test(pathname))
      return randomGlobal('Scene', 'scenes', '/scenes/');

    if (pathname === '/images' || /^\/images\/\d+$/.test(pathname))
      return randomGlobal('Image', 'images', '/images/');

    if (pathname === '/performers')
      return randomGlobal('Performer', 'performers', '/performers/');

    if (pathname === '/studios')
      return randomGlobal('Studio', 'studios', '/studios/');

    if (pathname === '/tags')
      return randomGlobal('Tag', 'tags', '/tags/');

    if (pathname === '/groups')
      return randomGlobal('Group', 'groups', '/groups/');

    if (pathname === '/galleries')
      return randomGlobal('Gallery', 'galleries', '/galleries/');

    let studioId = getIdFromPath(/^\/studios\/(\d+)\/scenes/);
    if (studioId)
      return randomGlobal('Scene', 'scenes', '/scenes/', {
        studios: { value: [studioId], modifier: "INCLUDES_ALL" }
      });

    let groupId = getIdFromPath(/^\/groups\/(\d+)\/scenes/);
    if (groupId)
      return randomGlobal('Scene', 'scenes', '/scenes/', {
        groups: { value: [groupId], modifier: "INCLUDES_ALL" }
      });

    let performerId = getIdFromPath(/^\/performers\/(\d+)\/scenes/);
    if (performerId)
      return randomGlobal('Scene', 'scenes', '/scenes/', {
        performers: { value: [performerId], modifier: "INCLUDES_ALL" }
      });

    let tagId = getIdFromPath(/^\/tags\/(\d+)\/scenes/);
    if (tagId)
      return randomGlobal('Scene', 'scenes', '/scenes/', {
        tags: { value: [tagId], modifier: "INCLUDES_ALL" }
      });

    let galleryId = getIdFromPath(/^\/galleries\/(\d+)$/);
    if (galleryId)
      return randomGlobal('Image', 'images', '/images/', {
        galleries: { value: [galleryId], modifier: "INCLUDES_ALL" }
      });

    DiceRLogger.log("error", "Unsupported path", { pathname });
    alert('Not supported');
  }

  /* ==========================
     BUTTON INJECTION
  ========================== */

  function addRandomButton() {
    if (document.querySelector('.random-btn')) return;

    const navContainer = document.querySelector('.navbar-buttons.flex-row.ml-auto.order-xl-2.navbar-nav');
    if (!navContainer) return;

    const container = document.createElement('div');
    container.className = 'mr-2';
    container.innerHTML = `
      <a href="javascript:void(0)">
        <button type="button" class="btn btn-primary random-btn">🎲Roll</button>
      </a>
    `;

    container.querySelector('button')
      .addEventListener('click', randomButtonHandler);

    navContainer.appendChild(container);

    DiceRLogger.log("success", "Random button added");
  }

  const observer = new MutationObserver(() => {
    if (document.querySelector('.navbar-buttons.flex-row.ml-auto.order-xl-2.navbar-nav')) {
      addRandomButton();
      observer.disconnect();
      DiceRLogger.log("event", "Observer disconnected");
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });

  document.addEventListener('click', () => setTimeout(addRandomButton, 1200));
  window.addEventListener('popstate', () => setTimeout(addRandomButton, 1200));
  window.addEventListener('hashchange', () => setTimeout(addRandomButton, 1200));

})();
